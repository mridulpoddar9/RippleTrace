import { describe, expect, it } from 'vitest';
import { analyzeSourceFiles, calculateDependencyRisks, getRippleExplanation, parseCvssVector, type DependencyInfo, type ScanFinding, type ScanResult, type SourceFile } from './analyzer';

describe('CVSS visibility', () => {
  it('parses a published CVSS v3 vector into a visible base score', () => {
    expect(parseCvssVector('CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H')).toBe(9.8);
  });
  it('returns undefined for advisories without a numeric/vector CVSS score', () => {
    expect(parseCvssVector(undefined)).toBeUndefined();
    expect(parseCvssVector('not-published')).toBeUndefined();
  });
});

describe('resolved relationship graph and Potential impact', () => {
  const fixture: SourceFile[] = [
    { path: 'routes/users.ts', language: 'TypeScript', size: 120, content: `import { getUser } from '../services/userService';\nexport function handler(req) { return getUser(req.query.id); }\nconst sql = "SELECT * FROM users WHERE id = " + req.query.id;` },
    { path: 'services/userService.ts', language: 'TypeScript', size: 100, content: `import { query } from '../db/database';\nexport function getUser(id) { return query(id); }` },
    { path: 'db/database.ts', language: 'TypeScript', size: 100, content: `export function query(id) { return "SELECT * FROM users WHERE id = " + id; }` },
  ];

  it('resolves routes/users.ts → userService.ts → database.ts and reports downstream impact', () => {
    const scan = analyzeSourceFiles(fixture);
    const finding = scan.findings[0];
    expect(scan.graph.edges.filter((edge) => edge.relation === 'imports').map((edge) => [edge.source, edge.target])).toEqual(expect.arrayContaining([
      ['file:routes/users.ts', 'file:services/userService.ts'],
      ['file:services/userService.ts', 'file:db/database.ts'],
    ]));
    expect(finding.affectedNodes).toEqual(['services/userService.ts', 'db/database.ts']);
    expect(finding.maxDownstreamDepth).toBe(2);
    expect(getRippleExplanation(finding, scan)).toContain('connected to 2 downstream components through confirmed import relationships');
    expect(getRippleExplanation(finding, scan)).toContain('Maximum detected propagation depth: 2');
    expect(finding.rippleScore).toBeGreaterThan(30);
  });

  it('uses the isolated message only when no relationship exists', () => {
    const scan = analyzeSourceFiles([{ path: 'src/isolated.ts', language: 'TypeScript', size: 80, content: `export function handler(req) { return eval(req.query.code); }` }]);
    const finding = scan.findings[0];
    expect(finding.affectedNodes).toEqual([]);
    expect(getRippleExplanation(finding, scan)).toContain('The finding currently appears isolated');
  });
});

describe('calculateDependencyRisks', () => {
  it('ranks ecosystem connectivity separately from CVSS', () => {
    const dependencies: DependencyInfo[] = [
      { name: 'package-a', version: '1.0.0', manifest: 'package.json', cvss: 9.1 },
      { name: 'package-b', version: '1.0.0', manifest: 'package.json', cvss: 7.2 },
      { name: 'package-c', version: '1.0.0', manifest: 'package.json', cvss: 9.8 },
    ];
    const files: SourceFile[] = [
      { path: 'package.json', content: '{}', language: 'JSON', size: 2 },
      { path: 'src/worker-a.ts', content: "import a from 'package-a';", language: 'TypeScript', size: 25 },
      { path: 'src/api/orders.ts', content: "import b from 'package-b';", language: 'TypeScript', size: 25 },
      { path: 'src/routes/admin.ts', content: "import b from 'package-b';", language: 'TypeScript', size: 25 },
      { path: 'src/services/billing.ts', content: "import b from 'package-b';", language: 'TypeScript', size: 25 },
      { path: 'src/critical/checkout.ts', content: "import b from 'package-b';", language: 'TypeScript', size: 25 },
      { path: 'src/api/profile.ts', content: "import c from 'package-c';", language: 'TypeScript', size: 25 },
    ];
    const risks = calculateDependencyRisks(dependencies, files);
    const packageB = risks.find((risk) => risk.name === 'package-b');
    expect(packageB?.directDependents).toBe(4);
    expect(packageB?.criticalApps).toBe(4);
    expect(packageB?.blastRadius).toBeGreaterThan(risks.find((risk) => risk.name === 'package-a')?.blastRadius ?? 100);
    expect(risks[0].name).toBe('package-b');
  });
});
