import JSZip from 'jszip';

export type Severity = 'critical' | 'high' | 'medium' | 'low';
export type Confidence = 'high' | 'medium' | 'low';
export type FindingStatus = 'open' | 'reviewed' | 'false-positive' | 'ignored' | 'resolved';
export type NodeKind = 'entry' | 'file' | 'dependency' | 'vulnerable';

export type SourceFile = { path: string; content: string; language: string; size: number };
export type ScanFinding = {
  id: string; title: string; category: string; severity: Severity; confidence: Confidence;
  file: string; line: number; evidence: string; description: string; remediation: string;
  references: string[]; affectedNodes: string[]; rippleScore: number; status: FindingStatus;
  directDownstream?: number; totalDownstream?: number; maxDownstreamDepth?: number; relationshipConfidence?: number;
};
export type GraphNode = { id: string; label: string; kind: NodeKind; file?: string; severity?: Severity };
export type GraphEdge = { source: string; target: string; relation: 'imports' | 'depends-on' | 'contains' | 'potential-impact'; confidence?: number; evidence?: string };
export type ScanResult = {
  scanId: string; projectName: string; mode: 'real' | 'demo'; timestamp: string; scannerVersion: string;
  origin?: string; filesScanned: number; filesSkipped: number; skippedPaths: string[]; dependencies: DependencyInfo[]; dependencyRisks?: DependencyRisk[];
  findings: ScanFinding[]; graph: { nodes: GraphNode[]; edges: GraphEdge[] }; rippleScore: number;
  statistics: { critical: number; high: number; medium: number; low: number; secrets: number; checks: number };
};
export type DependencyAdvisory = { id: string; summary: string; severity: Severity; fixed?: string; source: 'OSV' };
export type DependencyInfo = { name: string; version: string; manifest: string; advisories?: DependencyAdvisory[]; cvss?: number; intelligence?: 'checked' | 'unavailable' };
export type DependencyRisk = DependencyInfo & { directDependents: number; criticalApps: number; blastRadius: number; dependentComponents: string[]; criticalAppComponents: string[] };
export type RippleExplanationMetrics = {
  affectedComponents: number; directDownstream: number; maxDepth: number; downstreamRelationships: number;
  centrality: number; confirmedRelationships: number; inferredRelationships: number; downstreamDependencies: number;
  relationshipConfidence: number; components: string[]; exposure?: string;
};

export const UPLOAD_LIMITS = { FREE: 7 * 1024 * 1024, PRO: 70 * 1024 * 1024, STUDIO: 250 * 1024 * 1024 } as const;
const MAX_FILES = 800;
const ignored = /(^|\/)(node_modules|\.git|dist|build|coverage|\.next|vendor|target|\.cache)(\/|$)/i;
const binaryExt = /\.(png|jpe?g|gif|webp|ico|pdf|zip|gz|woff2?|ttf|mp[34]|mov|exe|dll|so|dylib|class|jar|o|a)$/i;
const languageByExt: Record<string, string> = { js: 'JavaScript', jsx: 'JavaScript', ts: 'TypeScript', tsx: 'TypeScript', py: 'Python', java: 'Java', c: 'C', cc: 'C++', cpp: 'C++', h: 'C/C++', hpp: 'C/C++', go: 'Go', php: 'PHP', rb: 'Ruby', rs: 'Rust', cs: 'C#', json: 'JSON', toml: 'TOML', yaml: 'YAML', yml: 'YAML', xml: 'XML', sql: 'SQL' };
const extFor = (path: string) => path.split('.').pop()?.toLowerCase() ?? '';
const languageFor = (path: string) => languageByExt[extFor(path)] ?? 'Text';
const supported = (path: string) => Boolean(languageByExt[extFor(path)]) || /(^|\/)(package\.json|requirements\.txt|pyproject\.toml|pom\.xml|build\.gradle|go\.mod|composer\.json|Cargo\.toml)$/i.test(path);
const cleanPath = (path: string) => path.replaceAll('\\', '/').replace(/^\/+/, '');

async function collectFiles(file: File, maxBytes: number): Promise<{ files: SourceFile[]; skippedPaths: string[]; projectName: string }> {
  if (file.size > maxBytes) throw new Error(`This project is ${formatBytes(file.size)}, which exceeds the ${formatBytes(maxBytes)} upload limit for the selected plan.`);
  const skippedPaths: string[] = [];
  const source: SourceFile[] = [];
  const add = (path: string, content: string, size: number) => {
    const clean = cleanPath(path);
    if (ignored.test(clean) || binaryExt.test(clean) || !supported(clean) || size > 500_000) { skippedPaths.push(clean); return; }
    source.push({ path: clean, content, language: languageFor(clean), size });
  };
  if (file.name.toLowerCase().endsWith('.zip')) {
    const zip = await JSZip.loadAsync(await file.arrayBuffer(), { createFolders: false });
    const entries = Object.values(zip.files).filter((entry) => !entry.dir);
    if (entries.length > MAX_FILES) throw new Error('This archive contains too many files to scan safely.');
    for (const entry of entries) {
      const path = cleanPath(entry.name);
      if (ignored.test(path) || binaryExt.test(path) || !supported(path)) { skippedPaths.push(path); continue; }
      const content = await entry.async('string');
      add(path, content, content.length);
    }
    if (!source.length) throw new Error('No analyzable source files were found in this archive.');
    return { files: source, skippedPaths, projectName: file.name.replace(/\.zip$/i, '') };
  }
  if (!supported(file.name)) throw new Error("This file type isn't currently supported.");
  add(file.name, await file.text(), file.size);
  return { files: source, skippedPaths, projectName: file.name.replace(/\.[^.]+$/, '') };
}

export function formatBytes(bytes: number) { return `${Math.round((bytes / 1024 / 1024) * 10) / 10} MB`; }

function manifestDependencies(files: SourceFile[]) {
  const dependencies: ScanResult['dependencies'] = [];
  for (const file of files) {
    if (file.path.endsWith('package.json')) {
      try {
        const data = JSON.parse(file.content);
        for (const [name, version] of Object.entries({ ...(data.dependencies ?? {}), ...(data.devDependencies ?? {}) })) dependencies.push({ name, version: String(version), manifest: file.path });
      } catch { /* malformed manifests remain visible through source evidence */ }
    } else if (file.path.endsWith('requirements.txt')) {
      for (const line of file.content.split(/\r?\n/)) { const match = line.match(/^\s*([A-Za-z0-9_.-]+)\s*(?:==|>=|~=)?\s*([\w.*-]+)?/); if (match?.[1] && !line.trim().startsWith('#')) dependencies.push({ name: match[1], version: match[2] ?? 'unspecified', manifest: file.path }); }
    } else if (file.path.endsWith('go.mod')) {
      for (const match of Array.from(file.content.matchAll(/^\s*([\w./-]+)\s+v([\w.-]+)/gm))) dependencies.push({ name: match[1], version: `v${match[2]}`, manifest: file.path });
    } else if (file.path.endsWith('Cargo.toml')) {
      for (const line of file.content.split(/\r?\n/)) { const match = line.match(/^\s*([\w-]+)\s*=\s*["']([^"']+)["']/); if (match) dependencies.push({ name: match[1], version: match[2], manifest: file.path }); }
    }
  }
  return dependencies;
}

export function parseCvssVector(vector?: string): number | undefined {
  if (!vector || !vector.startsWith('CVSS:3')) return undefined;
  const metrics = Object.fromEntries(vector.split('/').slice(1).map((part) => part.split(':', 2))) as Record<string, string>;
  const av: Record<string, number> = { N: 0.85, A: 0.62, L: 0.55, P: 0.2 };
  const ac: Record<string, number> = { L: 0.77, H: 0.44 };
  const prU: Record<string, number> = { N: 0.85, L: 0.62, H: 0.27 };
  const prC: Record<string, number> = { N: 0.85, L: 0.68, H: 0.5 };
  const ui: Record<string, number> = { N: 0.85, R: 0.62 };
  const impact: Record<string, number> = { H: 0.56, L: 0.22, N: 0 };
  if (!av[metrics.AV] || !ac[metrics.AC] || !ui[metrics.UI] || metrics.S !== 'U' && metrics.S !== 'C') return undefined;
  const pr = (metrics.S === 'C' ? prC : prU)[metrics.PR];
  if (!pr || impact[metrics.C] === undefined || impact[metrics.I] === undefined || impact[metrics.A] === undefined) return undefined;
  const iscBase = 1 - ((1 - impact[metrics.C]) * (1 - impact[metrics.I]) * (1 - impact[metrics.A]));
  const isc = metrics.S === 'U' ? 6.42 * iscBase : 7.52 * (iscBase - 0.029) - 3.25 * Math.pow(iscBase - 0.02, 15);
  if (isc <= 0) return 0;
  const exploitability = 8.22 * av[metrics.AV] * ac[metrics.AC] * pr * ui[metrics.UI];
  const base = metrics.S === 'U' ? Math.min(isc + exploitability, 10) : Math.min(1.08 * (isc + exploitability), 10);
  return Math.ceil((Math.max(0, base) + Number.EPSILON) * 10) / 10;
}

async function enrichDependencies(dependencies: ScanResult['dependencies']) {
  return Promise.all(dependencies.map(async (dependency) => {
    if (!dependency.version || /^(latest|\*|unspecified|[~^><=])/.test(dependency.version)) return { ...dependency, intelligence: 'unavailable' as const };
    try {
      const response = await fetch('https://api.osv.dev/v1/query', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ package: { name: dependency.name }, version: dependency.version.replace(/^[^\d]*/, '') }) });
      if (!response.ok) return { ...dependency, intelligence: 'unavailable' as const };
      const data = await response.json() as { vulns?: Array<{ id?: string; summary?: string; database_specific?: { severity?: string }; severity?: Array<{ score?: string }>; affected?: Array<{ ranges?: Array<{ events?: Array<{ fixed?: string }> }> }> }> };
      const advisories = (data.vulns ?? []).map((vulnerability) => ({ id: vulnerability.id ?? 'OSV advisory', summary: vulnerability.summary ?? 'OSV reported an advisory for this dependency version.', severity: /critical/i.test(vulnerability.database_specific?.severity ?? '') ? 'critical' as Severity : /high/i.test(vulnerability.database_specific?.severity ?? '') ? 'high' as Severity : /low/i.test(vulnerability.database_specific?.severity ?? '') ? 'low' as Severity : 'medium' as Severity, fixed: vulnerability.affected?.[0]?.ranges?.[0]?.events?.find((event) => event.fixed)?.fixed, source: 'OSV' as const }));
      const cvssScores = (data.vulns ?? []).flatMap((vulnerability) => (vulnerability.severity ?? []).map((item) => parseCvssVector(item.score)) .filter((score): score is number => score !== undefined));
      const cvss = cvssScores.length ? Math.max(...cvssScores) : undefined;
      return { ...dependency, advisories, ...(cvss !== undefined ? { cvss } : {}), intelligence: 'checked' as const };
    } catch { return { ...dependency, intelligence: 'unavailable' as const }; }
  }));
}

const ruleSet = [
  { id: 'sql-injection', title: 'Potential SQL injection', category: 'Injection', severity: 'high' as Severity, confidence: 'medium' as Confidence, pattern: /(SELECT|INSERT|UPDATE|DELETE)[^\n]*(\+|`|\$\{|f["'])/i, why: 'A query appears to combine SQL syntax with interpolated or concatenated input.', fix: 'Use parameterized queries or a safe query builder and validate inputs at the boundary.', ref: 'https://owasp.org/www-community/attacks/SQL_Injection' },
  { id: 'command-injection', title: 'Potential command injection', category: 'Command execution', severity: 'critical' as Severity, confidence: 'high' as Confidence, pattern: /(child_process\.(exec|execSync)|os\.system\s*\(|subprocess\.(run|Popen|call)\s*\()/, why: 'A shell or process execution API is called from source and may be reachable with user-controlled data.', fix: 'Avoid shell execution; use an argument array, strict allowlists, and isolate untrusted input.', ref: 'https://owasp.org/www-community/attacks/Command_Injection' },
  { id: 'path-traversal', title: 'Potential path traversal', category: 'File access', severity: 'high' as Severity, confidence: 'medium' as Confidence, pattern: /(readFile|writeFile|open|sendFile|unlink|Path\(|open\()[^\n]*(req\.|query|params|input|user|\.\.)/i, why: 'A file operation appears to receive request or user-controlled path data.', fix: 'Resolve against a fixed directory, reject traversal segments, and enforce an allowlist of files.', ref: 'https://owasp.org/www-community/attacks/Path_Traversal' },
  { id: 'dynamic-execution', title: 'Dangerous dynamic execution', category: 'Code execution', severity: 'high' as Severity, confidence: 'high' as Confidence, pattern: /\beval\s*\(|new Function\s*\(|exec\s*\(/, why: 'Dynamic code evaluation can turn untrusted strings into executable code.', fix: 'Remove dynamic evaluation and use explicit parsers or constrained interpreters.', ref: 'https://owasp.org/www-community/attacks/Code_Injection' },
  { id: 'hardcoded-secret', title: 'Possible hard-coded secret', category: 'Secrets', severity: 'high' as Severity, confidence: 'medium' as Confidence, pattern: /(api[_-]?key|secret|token|password)\s*[:=]\s*["'][A-Za-z0-9_\-./+=]{12,}["']/i, why: 'A credential-like value appears directly in source code.', fix: 'Rotate the value, remove it from source control, and load secrets from managed environment storage.', ref: 'https://owasp.org/www-community/vulnerabilities/Use_of_hard-coded_password' },
  { id: 'weak-crypto', title: 'Weak cryptography or hash', category: 'Cryptography', severity: 'medium' as Severity, confidence: 'medium' as Confidence, pattern: /(md5|sha1|des|rc4)\s*\(/i, why: 'A weak or legacy cryptographic primitive is referenced.', fix: 'Use a modern, vetted primitive such as SHA-256 for integrity or Argon2/bcrypt for passwords.', ref: 'https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html' },
  { id: 'unsafe-deserialization', title: 'Potential unsafe deserialization', category: 'Deserialization', severity: 'high' as Severity, confidence: 'low' as Confidence, pattern: /(pickle\.loads|yaml\.load\s*\([^\n]*Loader\s*=\s*None|ObjectInputStream)/i, why: 'A deserialization API may construct objects from untrusted bytes.', fix: 'Use safe loading modes and validate the data schema before object construction.', ref: 'https://owasp.org/www-community/vulnerabilities/Deserialization_of_untrusted_data' },
  { id: 'sensitive-log', title: 'Sensitive information in logs', category: 'Information exposure', severity: 'medium' as Severity, confidence: 'low' as Confidence, pattern: /(console\.log|print|logger\.(info|debug))[^\n]*(password|token|secret|authorization)/i, why: 'A log statement appears to include credential-like data.', fix: 'Redact sensitive fields before logging and review log retention/access controls.', ref: 'https://owasp.org/www-project-top-ten/2017/A3_2017-Sensitive_Data_Exposure' },
];

function normalizePath(path: string) {
  const parts: string[] = [];
  for (const part of path.replaceAll('\\', '/').split('/')) { if (!part || part === '.') continue; if (part === '..') parts.pop(); else parts.push(part); }
  return parts.join('/');
}
function dirname(path: string) { const index = path.lastIndexOf('/'); return index >= 0 ? path.slice(0, index) : ''; }
function escapeRegExp(value: string) { return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
function importSpecs(file: SourceFile): Array<{ spec: string; evidence: string }> {
  const found: Array<{ spec: string; evidence: string }> = [];
  const add = (spec: string, evidence: string) => { if (spec && !spec.startsWith('node:')) found.push({ spec, evidence: evidence.trim() }); };
  const jsPatterns = [/\bimport\s+(?:[\s\S]*?\s+from\s+)?["']([^"']+)["']/g, /\bexport\s+(?:[\s\S]*?\s+from\s+)["']([^"']+)["']/g, /\brequire\s*\(\s*["']([^"']+)["']\s*\)/g];
  if (/JavaScript|TypeScript/.test(file.language)) for (const pattern of jsPatterns) for (const match of Array.from(file.content.matchAll(pattern))) add(match[1], match[0]);
  if (file.language === 'Python') { for (const match of Array.from(file.content.matchAll(/^\s*from\s+([.\w/]+)\s+import\s+[^\n]+/gm))) add(match[1], match[0]); for (const match of Array.from(file.content.matchAll(/^\s*import\s+([.\w/]+)/gm))) add(match[1], match[0]); }
  if (file.language === 'Java') for (const match of Array.from(file.content.matchAll(/^\s*import\s+([\w.]+)\s*;/gm))) add(match[1], match[0]);
  if (file.language === 'Go') for (const match of Array.from(file.content.matchAll(/["']([^"']+)["']/g))) add(match[1], match[0]);
  return found;
}
function resolveImport(file: SourceFile, spec: string, files: SourceFile[]) {
  const candidates: string[] = [];
  if (spec.startsWith('.')) candidates.push(normalizePath(`${dirname(file.path)}/${spec}`));
  else if (spec.startsWith('@/')) candidates.push(normalizePath(`src/${spec.slice(2)}`));
  else if (spec.startsWith('/')) candidates.push(normalizePath(spec));
  else if (/Python|Java|Go/.test(file.language)) candidates.push(normalizePath(spec.replaceAll('.', '/')));
  if (!candidates.length) return undefined;
  const extensions = ['', '.ts', '.tsx', '.js', '.jsx', '.py', '.java', '.go', '.json'];
  for (const candidate of candidates) {
    for (const extension of extensions) { const exact = files.find((target) => target.path === `${candidate}${extension}`); if (exact) return exact; }
    const index = files.find((target) => extensions.some((extension) => target.path === `${candidate}/index${extension}`));
    if (index) return index;
  }
  return undefined;
}
function buildImportEdges(files: SourceFile[]): GraphEdge[] {
  const edges: GraphEdge[] = [];
  for (const file of files) for (const imported of importSpecs(file)) { const target = resolveImport(file, imported.spec, files); if (target && target.path !== file.path) edges.push({ source: `file:${file.path}`, target: `file:${target.path}`, relation: 'imports', confidence: 1, evidence: imported.evidence }); }
  return edges;
}

function downstreamFor(filePath: string, edges: GraphEdge[]) {
  const queue: Array<{ id: string; depth: number }> = [{ id: `file:${filePath}`, depth: 0 }];
  const visited = new Set<string>([`file:${filePath}`]);
  const nodes: Array<{ path: string; depth: number; edge?: GraphEdge }> = [];
  while (queue.length) {
    const current = queue.shift()!;
    for (const edge of edges.filter((candidate) => candidate.source === current.id && candidate.relation === 'imports')) {
      if (visited.has(edge.target)) continue;
      visited.add(edge.target);
      const path = edge.target.replace(/^file:/, '');
      const depth = current.depth + 1;
      nodes.push({ path, depth, edge });
      queue.push({ id: edge.target, depth });
    }
  }
  return nodes;
}

export function getFindingMetrics(finding: ScanFinding, scan: ScanResult): RippleExplanationMetrics {
  const downstream = downstreamFor(finding.file, scan.graph.edges);
  const potential = scan.graph.edges.filter((edge) => edge.source === `finding:${finding.id}` && edge.relation === 'potential-impact');
  const components = downstream.length ? downstream.map((item) => item.path) : finding.affectedNodes;
  const totalDownstream = finding.totalDownstream ?? components.length;
  const directDownstream = finding.directDownstream ?? (downstream.length ? downstream.filter((item) => item.depth === 1).length : components.length ? components.length : 0);
  const maxDepth = finding.maxDownstreamDepth ?? (downstream.length ? Math.max(...downstream.map((item) => item.depth)) : components.length ? 1 : 0);
  const importEdges = scan.graph.edges.filter((edge) => edge.relation === 'imports' && (edge.source === `file:${finding.file}` || components.some((path) => edge.source === `file:${path}`)));
  const confirmedRelationships = downstream.filter((item) => item.edge?.confidence === 1).length || potential.filter((edge) => edge.confidence === 1 || edge.confidence === undefined).length;
  const inferredRelationships = downstream.filter((item) => item.edge && item.edge.confidence !== 1).length || potential.filter((edge) => edge.confidence !== 1 && edge.confidence !== undefined).length;
  const centrality = scan.graph.edges.filter((edge) => edge.source === `file:${finding.file}` || edge.target === `file:${finding.file}`).length;
  const downstreamDependencies = components.reduce((count, path) => count + scan.graph.edges.filter((edge) => edge.source === `file:${path}` && edge.relation === 'depends-on').length, 0);
  const confidenceValues = downstream.map((item) => item.edge?.confidence ?? 0).filter((value) => value > 0);
  const relationshipConfidence = confidenceValues.length ? Math.min(...confidenceValues) : inferredRelationships ? 0.5 : 0;
  const exposure = /(^|\/)(api|routes?|controllers?)(\/|\.)/i.test(finding.file) ? 'API or route reachability is present and should be validated.' : undefined;
  return { affectedComponents: totalDownstream, directDownstream, maxDepth, downstreamRelationships: confirmedRelationships + inferredRelationships, centrality, confirmedRelationships, inferredRelationships, downstreamDependencies, relationshipConfidence, components, exposure };
}

export function calculateDependencyRisks(dependencies: DependencyInfo[], files: SourceFile[]): DependencyRisk[] {
  return dependencies.map((dependency) => {
    const escaped = escapeRegExp(dependency.name);
    const dependentComponents = files.filter((file) => file.path !== dependency.manifest && new RegExp(`(?:import|require|from|use|include)[^\\n]*${escaped}`, 'i').test(file.content)).map((file) => file.path);
    const criticalAppComponents = dependentComponents.filter((path) => /(^|\/)(api|routes?|services?|auth|billing|payments?|checkout|admin|prod|critical)(\/|\.|$)/i.test(path));
    const cvssContribution = dependency.cvss !== undefined ? Math.min(35, Math.round((dependency.cvss / 10) * 35)) : 0;
    const dependentContribution = Math.min(40, dependentComponents.length * 4);
    const criticalContribution = Math.min(25, criticalAppComponents.length * 10);
    return { ...dependency, directDependents: dependentComponents.length, criticalApps: criticalAppComponents.length, blastRadius: Math.min(100, cvssContribution + dependentContribution + criticalContribution), dependentComponents, criticalAppComponents };
  }).sort((a, b) => b.blastRadius - a.blastRadius);
}

function scanFiles(files: SourceFile[], dependencies: ScanResult['dependencies'], projectName: string, mode: 'real' | 'demo', skippedPaths: string[], origin = 'local upload'): ScanResult {
  const findings: ScanFinding[] = [];
  const graphNodes: GraphNode[] = [{ id: 'entry', label: projectName, kind: 'entry' }];
  const graphEdges: GraphEdge[] = buildImportEdges(files);
  files.forEach((file) => { graphNodes.push({ id: `file:${file.path}`, label: file.path.split('/').pop() ?? file.path, kind: 'file', file: file.path }); graphEdges.push({ source: 'entry', target: `file:${file.path}`, relation: 'contains', confidence: 1, evidence: 'Analyzed project file' }); });
  dependencies.forEach((dep) => { const id = `dep:${dep.name}`; if (!graphNodes.find((node) => node.id === id)) graphNodes.push({ id, label: `${dep.name}@${dep.version}`, kind: 'dependency' }); const manifestId = `file:${dep.manifest}`; graphEdges.push({ source: manifestId, target: id, relation: 'depends-on', confidence: 1, evidence: `Manifest declaration in ${dep.manifest}` }); });
  files.forEach((file) => {
    const lines = file.content.split(/\r?\n/);
    for (let index = 0; index < lines.length; index += 1) {
      const line = lines[index];
      for (const rule of ruleSet) {
        if (!rule.pattern.test(line)) continue;
        const id = `${rule.id}:${file.path}:${index + 1}`;
        const downstream = downstreamFor(file.path, graphEdges);
        const directDownstream = downstream.filter((item) => item.depth === 1).length;
        const totalDownstream = downstream.length;
        const maxDownstreamDepth = downstream.length ? Math.max(...downstream.map((item) => item.depth)) : 0;
        const centrality = graphEdges.filter((edge) => edge.source === `file:${file.path}` || edge.target === `file:${file.path}`).length;
        const relationshipConfidence = downstream.length ? Math.min(...downstream.map((item) => item.edge?.confidence ?? 0)) : 0;
        const severityBase = { critical: 24, high: 18, medium: 12, low: 6 }[rule.severity];
        const confidenceBase = { high: 12, medium: 8, low: 4 }[rule.confidence];
        const score = Math.min(100, Math.round(severityBase + confidenceBase + Math.min(30, totalDownstream * 6) + Math.min(18, maxDownstreamDepth * 6) + Math.min(12, Math.max(0, centrality - 1) * 3) + (/^src\/(api|routes?)(\/|$)/i.test(file.path) ? 8 : 0)));
        const affectedNodes = downstream.map((item) => item.path);
        const finding: ScanFinding = { id, title: rule.title, category: rule.category, severity: rule.severity, confidence: rule.confidence, file: file.path, line: index + 1, evidence: line.trim().replace(/(token|secret|password|api[_-]?key)\s*[:=]\s*["'][^"']+["']/ig, '$1: "[REDACTED]"'), description: rule.why, remediation: rule.fix, references: [rule.ref], affectedNodes, rippleScore: score, status: 'open', directDownstream, totalDownstream, maxDownstreamDepth, relationshipConfidence };
        findings.push(finding);
        const vulnId = `finding:${id}`;
        graphNodes.push({ id: vulnId, label: rule.title, kind: 'vulnerable', file: file.path, severity: rule.severity });
        graphEdges.push({ source: `file:${file.path}`, target: vulnId, relation: 'potential-impact', confidence: 1, evidence: line.trim() });
        downstream.forEach((item) => graphEdges.push({ source: vulnId, target: `file:${item.path}`, relation: 'potential-impact', confidence: item.edge?.confidence ?? 0.5, evidence: item.edge?.evidence }));
      }
    }
  });
  const stats = { critical: findings.filter((f) => f.severity === 'critical').length, high: findings.filter((f) => f.severity === 'high').length, medium: findings.filter((f) => f.severity === 'medium').length, low: findings.filter((f) => f.severity === 'low').length, secrets: findings.filter((f) => f.category === 'Secrets').length, checks: ruleSet.length };
  const rippleScore = findings.length ? Math.round(findings.reduce((sum, finding) => sum + finding.rippleScore, 0) / findings.length) : 0;
  return { scanId: `scan_${Date.now()}`, projectName, mode, origin, timestamp: new Date().toISOString(), scannerVersion: '1.0.0-real', filesScanned: files.length, filesSkipped: skippedPaths.length, skippedPaths, dependencies, dependencyRisks: calculateDependencyRisks(dependencies, files), findings, graph: { nodes: graphNodes, edges: graphEdges }, rippleScore, statistics: stats };
}

export function analyzeSourceFiles(files: SourceFile[], projectName = 'fixture project') { return scanFiles(files, [], projectName, 'real', [], 'test fixture'); }

export function getRippleExplanation(finding: ScanFinding, scan: ScanResult): string {
  const metrics = getFindingMetrics(finding, scan);
  if (metrics.affectedComponents === 0 && metrics.inferredRelationships === 0) return `No downstream file relationship was confidently inferred from the analyzed project. The finding currently appears isolated. Ripple Score: ${finding.rippleScore}. Confidence is ${finding.confidence}.`;
  const names = metrics.components.slice(0, 3).map((path) => path.split('/').pop() ?? path).join(', ');
  const relationshipLabel = metrics.inferredRelationships > 0 && metrics.confirmedRelationships === 0 ? 'potential downstream components were inferred from available project relationships. These relationships require validation.' : `downstream components through confirmed import relationships, including ${names}.`;
  const impact = metrics.inferredRelationships > 0 && metrics.confirmedRelationships === 0 ? `${metrics.affectedComponents} ${relationshipLabel}` : `This finding is connected to ${metrics.affectedComponents} ${relationshipLabel}`;
  const scoreContext = finding.rippleScore >= 60 ? 'High ripple impact is supported by the measured downstream graph.' : finding.rippleScore < 35 ? 'The measured graph indicates limited propagation.' : 'The measured graph indicates a moderate propagation path.';
  const severityContext = finding.severity === 'critical' && finding.rippleScore < 35 ? ' Critical severity is separate from ripple impact because the vulnerable component has limited downstream connectivity.' : '';
  return `${impact} Maximum detected propagation depth: ${metrics.maxDepth}. Ripple Score: ${finding.rippleScore}. ${scoreContext}${severityContext} Relationship confidence: ${Math.round(metrics.relationshipConfidence * 100)}%.${metrics.exposure ? ` ${metrics.exposure}` : ''}`;
}

export async function analyzeUpload(file: File, maxBytes = UPLOAD_LIMITS.PRO): Promise<ScanResult> {
  const { files, skippedPaths, projectName } = await collectFiles(file, maxBytes);
  const dependencies = await enrichDependencies(manifestDependencies(files));
  return scanFiles(files, dependencies, projectName, 'real', skippedPaths, 'local upload');
}

export async function analyzeGithub(input: string, maxBytes = UPLOAD_LIMITS.PRO): Promise<ScanResult> {
  const normalized = input.trim().replace(/\.git\/?$/, '');
  const match = normalized.match(/github\.com\/([^/]+)\/([^/#?]+)/i);
  if (!match) throw new Error('Enter a public GitHub repository URL such as https://github.com/owner/repository.');
  const [, owner, repo] = match;
  let response: Response;
  try { response = await fetch(`https://api.github.com/repos/${owner}/${repo}/zipball`, { headers: { accept: 'application/vnd.github+json' } }); }
  catch { throw new Error('GitHub import is unavailable in this browser session. Upload the repository ZIP instead, or enable a GitHub connector for authenticated imports.'); }
  if (!response.ok) throw new Error(response.status === 404 ? 'Repository not found or not publicly accessible.' : 'GitHub could not provide this repository archive.');
  const blob = await response.blob();
  const scan = await analyzeUpload(new File([blob], `${owner}-${repo}.zip`, { type: 'application/zip' }), maxBytes);
  return { ...scan, projectName: `${owner}/${repo}`, origin: 'public GitHub repository' };
}

export async function analyzeDemo(): Promise<ScanResult> {
  const demoFiles: SourceFile[] = [
    { path: 'src/api/users.ts', language: 'TypeScript', size: 380, content: `import { exec } from 'child_process';\nimport express from 'express';\nimport _ from 'lodash';\nimport { getUser } from '../services/userService';\nexport function lookup(req, res) {\n  const sql = "SELECT * FROM users WHERE id = " + req.query.id;\n  exec(req.query.command);\n  console.log('token', process.env.API_TOKEN);\n  return res.json(getUser(sql));\n}` },
    { path: 'src/services/userService.ts', language: 'TypeScript', size: 140, content: `import { query } from '../db/database';\nexport function getUser(sql) { return query(sql); }` },
    { path: 'src/db/database.ts', language: 'TypeScript', size: 100, content: `import express from 'express';\nexport function query(sql) { return express.json()(sql); }` },
    { path: 'src/routes/admin.ts', language: 'TypeScript', size: 90, content: `import express from 'express';\nexport const adminRouter = express.Router();` },
    { path: 'src/routes/catalog.ts', language: 'TypeScript', size: 90, content: `import express from 'express';\nexport const catalogRouter = express.Router();` },
    { path: 'src/api/public.ts', language: 'TypeScript', size: 90, content: `import express from 'express';\nexport const publicRouter = express.Router();` },
    { path: 'src/services/notifications.ts', language: 'TypeScript', size: 90, content: `import express from 'express';\nexport const notifications = express.Router();` },
    { path: 'src/services/worker.ts', language: 'TypeScript', size: 90, content: `import _ from 'lodash';\nexport const queue = _.chunk([], 10);` },
    { path: 'src/config.ts', language: 'TypeScript', size: 120, content: `export const config = {\n  apiKey: "demo_1234567890_secret"\n}` },
    { path: 'package.json', language: 'JSON', size: 180, content: '{"dependencies":{"express":"4.18.2","lodash":"4.17.21","axios":"1.6.0"}}' },
  ];
  return scanFiles(demoFiles, [{ name: 'express', version: '4.18.2', manifest: 'package.json', cvss: 7.2, intelligence: 'unavailable' }, { name: 'lodash', version: '4.17.21', manifest: 'package.json', cvss: 9.8, intelligence: 'unavailable' }, { name: 'axios', version: '1.6.0', manifest: 'package.json', cvss: 9.1, intelligence: 'unavailable' }], 'RippleTrace demo project', 'demo', [], 'bundled demo project');
}
