import { useState } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  Check,
  ChevronRight,
  CircleDot,
  Copy,
  ExternalLink,
  GitBranch,
  Globe2,
  LockKeyhole,
  Menu,
  Network,
  Package,
  Radar,
  ScanSearch,
  ShieldCheck,
  Sparkles,
  Terminal,
  X,
  Zap,
} from "lucide-react";

const steps = [
  {
    number: "01",
    title: "Choose an entry point",
    text: "Start from an npm package, a GitHub repository, or a public URL. RippleTrace treats the thing you care about as the root of a graph—not a row in a spreadsheet.",
    icon: Package,
  },
  {
    number: "02",
    title: "Resolve the graph",
    text: "The engine follows direct and transitive relationships, preserving the paths that connect a root package to the systems that depend on it.",
    icon: Network,
  },
  {
    number: "03",
    title: "Surface exposure",
    text: "Each node is scored by its position in the graph, so you can see where a vulnerable package sits—and how far its consequences could travel.",
    icon: Radar,
  },
  {
    number: "04",
    title: "Act with context",
    text: "Read the blast radius as a map. Re-run a read-only scan, compare paths, and make a remediation decision with the chain of evidence in view.",
    icon: ShieldCheck,
  },
];

const files = [
  {
    name: "graphResolver.ts",
    tag: "engine",
    code: `export async function resolveGraph(root: RootTarget) {
  const manifest = await loadManifest(root)
  const nodes = await expandDependencies(manifest)

  return buildDependencyGraph({
    root,
    nodes,
    edges: inferRelationships(nodes),
  })
}`,
  },
  {
    name: "riskSurface.ts",
    tag: "analysis",
    code: `export function rankExposure(graph: DependencyGraph) {
  return graph.nodes
    .map((node) => ({
      ...node,
      depth: shortestPath(graph.root, node),
      fanOut: graph.outgoing(node).length,
    }))
    .sort((a, b) => b.fanOut - a.fanOut)
}`,
  },
  {
    name: "ScanPanel.tsx",
    tag: "interface",
    code: `function ScanPanel({ onTrace }: ScanPanelProps) {
  const [target, setTarget] = useState("")

  return (
    <form onSubmit={() => onTrace(target)}>
      <Input placeholder="Package, repository, or URL" />
      <Button type="submit">Trace dependency</Button>
    </form>
  )
}`,
  },
  {
    name: "cachePolicy.ts",
    tag: "runtime",
    code: `export const scanPolicy = {
  mode: "read-only",
  cacheTtl: 15 * 60,
  region: "US-EAST-1",
  engine: "0.8.4",
}`,
  },
];

const glossary = [
  ["Root target", "The package, repository, or URL you begin a trace from."],
  ["Direct dependency", "A relationship declared explicitly by the root target."],
  ["Transitive dependency", "A dependency introduced further down the chain."],
  ["Blast radius", "The set of paths and downstream nodes exposed by a change."],
];

function Home() {
  const [activeFile, setActiveFile] = useState(files[0]);
  const [copied, setCopied] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeStep, setActiveStep] = useState(1);

  const copyCode = async () => {
    await navigator.clipboard?.writeText(activeFile.code);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="site-shell">
      <header className="site-nav">
        <a href="#top" className="brand" aria-label="RippleTrace home">
          <span className="brand-mark"><span /><span /><span /></span>
          <span>Ripple<span className="brand-accent">Trace</span></span>
        </a>
        <nav className={menuOpen ? "nav-links nav-links--open" : "nav-links"}>
          <a href="#overview" onClick={() => setMenuOpen(false)}>Overview</a>
          <a href="#methodology" onClick={() => setMenuOpen(false)}>Methodology</a>
          <a href="#source" onClick={() => setMenuOpen(false)}>Source map</a>
          <a href="#glossary" onClick={() => setMenuOpen(false)}>Glossary</a>
        </nav>
        <div className="nav-actions">
          <span className="status-chip"><span className="status-dot" />Engine operational</span>
          <a className="nav-cta" href="https://rippleexpln-rbnximv7.manus.space/" target="_blank" rel="noreferrer">Open CVSS workspace <ExternalLink size={14} /></a>
          <button className="menu-button" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">{menuOpen ? <X size={20} /> : <Menu size={20} />}</button>
        </div>
      </header>

      <main id="top">
        <section className="hero section-dark">
          <div className="hero-grid" />
          <div className="hero-orbit hero-orbit--one" />
          <div className="hero-orbit hero-orbit--two" />
          <div className="container hero-inner">
            <div className="hero-copy">
              <div className="eyebrow eyebrow--lime"><Sparkles size={13} /> Supply-chain intelligence, decoded</div>
              <h1>See the blast radius <em>before</em> it becomes a fire drill.</h1>
              <p className="hero-lede">RippleTrace turns dependency chains into a readable map—so you can find the hidden paths behind an incident, a release, or a package you no longer trust.</p>
              <div className="hero-actions">
                <a className="button button--lime" href="#methodology">Learn how it works <ArrowDownRight size={17} /></a>
                <a className="text-link text-link--light" href="https://rippleexpln-rbnximv7.manus.space/" target="_blank" rel="noreferrer">Open the CVSS workspace <ArrowUpRight size={16} /></a>
              </div>
              <div className="hero-proof"><span>v0.8.4</span><i /> <span>US-EAST-1</span><i /> <span>Read-only by design</span></div>
            </div>

            <div className="trace-card-wrap">
              <div className="trace-card-glow" />
              <div className="trace-card">
                <div className="trace-card-top"><span className="overline">Live trace / 001</span><span className="trace-kicker"><CircleDot size={12} /> ready</span></div>
                <div className="trace-input"><span className="input-icon"><Package size={16} /></span><span>react-router</span><span className="input-type">npm</span></div>
                <div className="map-canvas" aria-label="Illustration of a dependency graph">
                  <svg className="map-lines" viewBox="0 0 440 250" fill="none" aria-hidden="true">
                    <path d="M104 126 C155 126, 150 70, 203 70" />
                    <path d="M104 126 C156 126, 158 182, 204 182" />
                    <path d="M235 70 C276 70, 281 37, 328 37" />
                    <path d="M235 70 C282 70, 287 117, 334 117" />
                    <path d="M235 182 C279 182, 284 208, 329 208" />
                    <path d="M365 117 C389 117, 392 208, 329 208" />
                  </svg>
                  <div className="graph-node graph-node--root"><span className="graph-node__pulse" /><span>react-router</span><small>root / npm</small></div>
                  <div className="graph-node graph-node--a"><span>history</span><small>direct</small></div>
                  <div className="graph-node graph-node--b"><span>tiny-invariant</span><small>direct</small></div>
                  <div className="graph-node graph-node--c"><span>scheduler</span><small>transitive</small></div>
                  <div className="graph-node graph-node--d graph-node--hot"><span>react-dom</span><small>high fan-out</small></div>
                  <div className="graph-node graph-node--e"><span>source-map</span><small>transitive</small></div>
                </div>
                <div className="trace-result"><div><span className="result-label">Exposure surface</span><strong>14 paths <ArrowUpRight size={14} /></strong></div><div className="result-divider" /><div><span className="result-label">Scan freshness</span><strong>02:14 ago</strong></div></div>
              </div>
              <div className="trace-caption"><span className="trace-caption__line" /> A dependency map is a story about relationships, not just packages.</div>
            </div>
          </div>
          <div className="hero-bottom container"><span>Scroll to explore the system</span><span className="scroll-line" /></div>
        </section>

        <section id="overview" className="section section-paper intro-section">
          <div className="container">
            <div className="section-heading section-heading--split"><div><div className="eyebrow"><span className="eyebrow-number">01</span> The app, decoded</div><h2>Infrastructure is a graph.<br /><span>Start seeing it that way.</span></h2></div><p>RippleTrace is a focused workspace for tracing dependency relationships before they turn into unknowns. It keeps the map legible, the scan safe, and the next decision close at hand.</p></div>
            <div className="feature-grid">
              <article className="feature-card feature-card--dark"><div className="feature-icon"><ScanSearch size={20} /></div><span className="feature-index">01 / INPUT</span><h3>Bring your real-world starting point</h3><p>Trace a package name, GitHub repository, or URL. One entry point is enough to begin building the dependency story.</p><a className="card-link" href="#methodology">See the workflow <ChevronRight size={15} /></a></article>
              <article className="feature-card feature-card--lime"><div className="feature-icon"><GitBranch size={20} /></div><span className="feature-index">02 / MAP</span><h3>Follow the paths that matter</h3><p>Direct and transitive dependencies become a visual graph, making the important relationships easier to scan than a flat audit log.</p><a className="card-link" href="#source">Read the source map <ChevronRight size={15} /></a></article>
              <article className="feature-card feature-card--outline"><div className="feature-icon"><LockKeyhole size={20} /></div><span className="feature-index">03 / POSTURE</span><h3>Investigate without changing anything</h3><p>Read-only scans and a 15-minute cache window create a safe surface for exploration when the stakes are high.</p><a className="card-link" href="#glossary">Understand the language <ChevronRight size={15} /></a></article>
            </div>
          </div>
        </section>

        <section id="methodology" className="section section-ink methodology-section">
          <div className="container">
            <div className="section-heading section-heading--light"><div><div className="eyebrow eyebrow--lime"><span className="eyebrow-number">02</span> Methodology</div><h2>A four-step trace.<br /><span>One clearer answer.</span></h2></div><p>Every scan follows the same simple arc: define the root, expand the relationships, rank the exposure, then hand the context back to the engineer.</p></div>
            <div className="steps-layout">
              <div className="step-list">{steps.map((step, index) => { const Icon = step.icon; return <button key={step.number} className={`step-item ${activeStep === index ? "step-item--active" : ""}`} onClick={() => setActiveStep(index)}><span className="step-number">{step.number}</span><span className="step-icon"><Icon size={17} /></span><span className="step-title">{step.title}</span><ChevronRight className="step-arrow" size={16} /></button>; })}</div>
              <div className="step-detail"><div className="detail-orb"><span>0{activeStep + 1}</span></div><div className="eyebrow eyebrow--lime">What happens here</div><h3>{steps[activeStep].title}</h3><p>{steps[activeStep].text}</p><div className="detail-meta"><span>Trace stage</span><span className="detail-meta-line" /><span>{String(activeStep + 1).padStart(2, "0")} / 04</span></div></div>
            </div>
          </div>
        </section>

        <section id="source" className="section section-paper source-section">
          <div className="container">
            <div className="section-heading section-heading--split"><div><div className="eyebrow"><span className="eyebrow-number">03</span> Source map</div><h2>Good tooling should<br /><span>show its working.</span></h2></div><p>Here’s the implementation story behind the experience: a root target enters the resolver, the graph is ranked for exposure, and the interface gives the result a readable shape.</p></div>
            <div className="code-shell">
              <aside className="file-list"><div className="file-list-head"><Terminal size={15} /> Code reference</div>{files.map((file) => <button key={file.name} className={`file-item ${activeFile.name === file.name ? "file-item--active" : ""}`} onClick={() => setActiveFile(file)}><span className="file-dot" />{file.name}<span className="file-tag">{file.tag}</span></button>)}<div className="file-list-note"><span className="status-dot" /> four core paths<br /><small>Mapped to the visible product behavior</small></div></aside>
              <div className="code-view"><div className="code-toolbar"><div><span className="code-language">TypeScript</span><span className="code-file-name">/ {activeFile.name}</span></div><button className="copy-button" onClick={copyCode}>{copied ? <><Check size={14} /> Copied</> : <><Copy size={14} /> Copy snippet</>}</button></div><pre><code>{activeFile.code}</code></pre><div className="code-footer"><span><span className="code-dot" /> Reference implementation</span><span>RippleTrace / explainer</span></div></div>
            </div>
            <div className="source-note"><div className="source-note-icon"><Globe2 size={18} /></div><p><strong>A note on source transparency.</strong> The CVSS workspace copy is a separate verified build. It adds visible CVSS base scores, resolved import relationships, graph-backed downstream impact, and transparent propagation depth while leaving the latest draft unchanged.</p><a href="https://rippleexpln-rbnximv7.manus.space/" target="_blank" rel="noreferrer">Visit CVSS workspace <ArrowUpRight size={15} /></a></div>
          </div>
        </section>

        <section id="glossary" className="section section-warm glossary-section">
          <div className="container glossary-layout"><div><div className="eyebrow"><span className="eyebrow-number">04</span> Shared language</div><h2>Make the map<br /><span>feel obvious.</span></h2><p className="glossary-lede">The fastest way to make dependency risk actionable is to give every relationship a name your team can use.</p><a className="text-link text-link--dark" href="#top">Back to top <ArrowUpRight size={16} /></a></div><div className="glossary-list">{glossary.map(([term, definition], index) => <div className="glossary-row" key={term}><span className="glossary-count">0{index + 1}</span><div><h3>{term}</h3><p>{definition}</p></div><ChevronRight size={17} /></div>)}</div></div>
        </section>

        <section className="cta-section section-dark"><div className="container cta-inner"><div><div className="eyebrow eyebrow--lime"><Zap size={13} /> Ready when you are</div><h2>Trace the thing<br /><em>before</em> it traces you.</h2></div><div className="cta-side"><p>Open the CVSS workspace to see dependency risk, published CVSS, and downstream impact in one evidence-backed workspace.</p><a className="button button--lime" href="https://rippleexpln-rbnximv7.manus.space/" target="_blank" rel="noreferrer">Open CVSS workspace <ExternalLink size={16} /></a></div></div></section>
      </main>

      <footer className="site-footer section-dark"><div className="container footer-inner"><a href="#top" className="brand brand--footer"><span className="brand-mark"><span /><span /><span /></span><span>Ripple<span className="brand-accent">Trace</span></span></a><span className="footer-note">Dependency intelligence, explained.</span><div className="footer-right"><a href="https://rippleexpln-rbnximv7.manus.space/" target="_blank" rel="noreferrer">CVSS workspace <ExternalLink size={13} /></a><span>verified prototype / US-EAST-1</span></div></div></footer>
    </div>
  );
}

export default Home;
